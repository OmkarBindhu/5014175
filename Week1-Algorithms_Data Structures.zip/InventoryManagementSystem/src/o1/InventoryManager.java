package o1;

import java.util.HashMap;
import java.util.Map;

public class InventoryManager {
    private Map<String, Product> inventory = new HashMap<>();

    // Add a product
    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }

    // Update a product
    public void updateProduct(String productId, Product updatedProduct) {
        if (inventory.containsKey(productId)) {
            inventory.put(productId, updatedProduct);
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }

    // Delete a product
    public void deleteProduct(String productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }

    // Display all products
    public void displayProducts() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        // Create some products
        Product p1 = new Product("001", "Laptop", 10, 999.99);
        Product p2 = new Product("002", "Smartphone", 25, 499.99);

        // Add products to the inventory
        manager.addProduct(p1);
        manager.addProduct(p2);

        // Display products
        System.out.println("Inventory after adding products:");
        manager.displayProducts();

        // Update a product
        Product p1Updated = new Product("001", "Laptop", 15, 899.99);
        manager.updateProduct("001", p1Updated);

        // Display products after update
        System.out.println("\nInventory after updating product:");
        manager.displayProducts();

        // Delete a product
        manager.deleteProduct("002");

        // Display products after deletion
        System.out.println("\nInventory after deleting product:");
        manager.displayProducts();
    }
}
