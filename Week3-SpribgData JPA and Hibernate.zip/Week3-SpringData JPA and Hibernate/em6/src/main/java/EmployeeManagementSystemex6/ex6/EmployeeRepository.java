package EmployeeManagementSystemex6.ex6;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
	public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	    // Find employees by their name
	    List<Employee> findByName(String name);

	    // Find employees by their department's name
	    List<Employee> findByDepartmentName(String departmentName);

	    // Find employees by their email containing a specific string
	    List<Employee> findByEmailContaining(String keyword);
	    Page<Employee> findAll(Pageable pageable);
	    List<Employee> findAll(Sort sort);

		List<Employee> findAll1(org.springframework.data.domain.Sort sortOrder);

		Employee save(Employee employee);

		Optional<Employee> findById(Long id);

		void deleteById(Long id);

		List<Employee> findAll(org.springframework.data.domain.Sort sortOrder);

		Employee save1(Employee employee);

	}

