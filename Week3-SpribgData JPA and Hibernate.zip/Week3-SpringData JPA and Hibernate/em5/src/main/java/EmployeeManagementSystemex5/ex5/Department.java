package EmployeeManagementSystemex5.ex5;
import jakarta.persistence.*;
import lombok.Data;
import java.util.List;
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @OneToMany(mappedBy = "department")
    private List<Employee> employees;

	public void setId(Long id2) {
		// TODO Auto-generated method stub
		
	}
}
