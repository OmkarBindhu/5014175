package EmployeeManagementSystemex9.ex9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
