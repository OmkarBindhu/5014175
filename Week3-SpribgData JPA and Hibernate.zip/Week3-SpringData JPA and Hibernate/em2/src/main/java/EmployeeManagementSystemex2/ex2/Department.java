package EmployeeManagementSystemex2.ex2;
import java.util.List;
public class Department {
    private Long id;
    private String name;
    private List<Employee> employees;
}

