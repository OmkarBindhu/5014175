package EmployeeManagementSystemex2.ex2;

public class Employee {
    private Long id;

    private String name;
    private String email;
    private Department department;
}
