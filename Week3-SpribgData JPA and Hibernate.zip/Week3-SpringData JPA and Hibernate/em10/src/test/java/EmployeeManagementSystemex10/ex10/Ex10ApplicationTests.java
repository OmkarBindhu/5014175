package EmployeeManagementSystemex10.ex10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
