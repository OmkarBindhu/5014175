package EmployeeManagementSystemex8.ex8;
public interface EmployeeNameProjection {
    String getName();
}
