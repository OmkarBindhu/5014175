package EmployeeManagementSystemex8.ex8;
import org.springframework.beans.factory.annotation.Value;

public class EmployeeSummary {

    private String name;
    private String departmentName;

    public EmployeeSummary(String name, String departmentName) {
        this.name = name;
        this.departmentName = departmentName;
    }

}

