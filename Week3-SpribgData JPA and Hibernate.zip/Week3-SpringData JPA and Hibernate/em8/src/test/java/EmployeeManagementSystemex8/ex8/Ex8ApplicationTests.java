package EmployeeManagementSystemex8.ex8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
