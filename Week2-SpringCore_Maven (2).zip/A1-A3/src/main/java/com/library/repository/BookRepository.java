package com.library.repository;

public class BookRepository {
    public void performRepositoryOperation() {
        System.out.println("BookRepository is performing an operation.");
    }
}
