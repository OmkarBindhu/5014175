package com.library.repository;

public class BookRepository {

    // Example method to demonstrate functionality
    @Override
    public String toString() {
        return "BookRepository{}";
    }
}
