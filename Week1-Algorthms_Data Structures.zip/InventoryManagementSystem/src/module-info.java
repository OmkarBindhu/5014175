/**
 * 
 */
/**
 * @author gbind
 *
 */
module InventoryManagementSystem {
}