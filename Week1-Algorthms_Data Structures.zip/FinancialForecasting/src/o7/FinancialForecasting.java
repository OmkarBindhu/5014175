package o7;

public class FinancialForecasting {

    // Recursive method to calculate future value
    public static double calculateFutureValue(double initialValue, double growthRate, int years) {
        // Base case: if no years are left, return the initial value
        if (years == 0) {
            return initialValue;
        }
        // Recursive case: calculate the future value for one less year
        return (1 + growthRate) * calculateFutureValue(initialValue, growthRate, years - 1);
    }

    public static void main(String[] args) {
        double initialValue = 1000; // Initial investment
        double annualGrowthRate = 0.05; // 5% annual growth rate
        int years = 10; // Predicting for 10 years

        double futureValue = calculateFutureValue(initialValue, annualGrowthRate, years);
        System.out.println("The future value after " + years + " years is: " + futureValue);
    }
}

