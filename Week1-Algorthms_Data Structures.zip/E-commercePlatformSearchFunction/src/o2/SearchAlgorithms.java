package o2;

import java.util.Arrays;

public class SearchAlgorithms {

    // Linear Search
    public static Product linearSearch(Product[] products, String productId) {
        for (Product product : products) {
            if (product.getProductId().equals(productId)) {
                return product;
            }
        }
        return null;
    }

    // Binary Search
    public static Product binarySearch(Product[] products, String productId) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].getProductId().equals(productId)) {
                return products[mid];
            }
            if (productId.compareTo(products[mid].getProductId()) < 0) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        // Sample Products
        Product[] products = {
            new Product("001", "Laptop", "Electronics"),
            new Product("002", "Smartphone", "Electronics"),
            new Product("003", "Tablet", "Electronics"),
            new Product("004", "Headphones", "Accessories")
        };

        // Linear Search Test
        System.out.println("Linear Search:");
        Product resultLinear = linearSearch(products, "003");
        System.out.println(resultLinear != null ? resultLinear : "Product not found.");

        // Binary Search Test (Sorted Array)
        Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId())); // Sort products by ID
        System.out.println("\nBinary Search:");
        Product resultBinary = binarySearch(products, "003");
        System.out.println(resultBinary != null ? resultBinary : "Product not found.");
    }
}
