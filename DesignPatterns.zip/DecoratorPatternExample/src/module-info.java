/**
 * 
 */
/**
 * @author gbind
 *
 */
module DecoratorPatternExample {
}