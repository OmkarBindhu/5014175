package o5;

public class DecoratorPatternDemo {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        
        Notifier smsNotifier = new SMSNotifierDecorator(new EmailNotifier());
        Notifier slackNotifier = new SlackNotifierDecorator(new SMSNotifierDecorator(new EmailNotifier()));

        System.out.println("Sending notifications:");
        
        emailNotifier.send("Hello, this is a test message.");
        smsNotifier.send("Hello, this is a test message.");
        slackNotifier.send("Hello, this is a test message.");
    }
}
