package o5;

public interface Notifier {
    void send(String message);
}

