/**
 * 
 */
/**
 * @author gbind
 *
 */
module DependencyInjectionExample {
}