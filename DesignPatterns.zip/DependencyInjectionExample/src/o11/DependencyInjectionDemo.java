package o11;

public class DependencyInjectionDemo {
    public static void main(String[] args) {
        // Create the repository implementation
        CustomerRepository customerRepository = new CustomerRepositoryImpl();
        
        // Inject the repository into the service
        CustomerService customerService = new CustomerService(customerRepository);

        // Use the service to find a customer
        String customerDetails = customerService.getCustomerDetails(1);
        System.out.println(customerDetails);
        String customerDetails1 = customerService.getCustomerDetails(2);
        System.out.println(customerDetails1);
    }
}
