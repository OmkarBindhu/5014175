/**
 * 
 */
/**
 * @author gbind
 *
 */
module FactoryMethodPatternExample {
}