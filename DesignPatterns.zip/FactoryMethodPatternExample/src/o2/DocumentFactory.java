package o2;

public abstract class DocumentFactory {
    public abstract Document createDocument();
}
