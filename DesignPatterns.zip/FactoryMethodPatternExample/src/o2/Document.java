package o2;

public interface Document {
    void open();
}
