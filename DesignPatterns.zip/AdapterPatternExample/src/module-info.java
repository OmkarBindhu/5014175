/**
 * 
 */
/**
 * @author gbind
 *
 */
module AdapterPatternExample {
}