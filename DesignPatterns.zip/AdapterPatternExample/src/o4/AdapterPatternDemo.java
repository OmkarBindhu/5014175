package o4;

public class AdapterPatternDemo {
    public static void main(String[] args) {
        // Create the adaptee objects
        PayPal payPal = new PayPal();
        Stripe stripe = new Stripe();

        // Create the adapters
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPal);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripe);

        // Use the adapters to process payments
        System.out.println("Using PayPal Adapter:");
        payPalAdapter.processPayment(100.00);

        System.out.println("\nUsing Stripe Adapter:");
        stripeAdapter.processPayment(200.00);
    }
}
