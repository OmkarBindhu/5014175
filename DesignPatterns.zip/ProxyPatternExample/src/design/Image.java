package design;

public interface Image {
    void display();
}
