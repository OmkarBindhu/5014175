/**
 * 
 */
/**
 * @author gbind
 *
 */
module ProxyPatternExample {
}