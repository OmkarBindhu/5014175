package O2;
public interface Observer {
    void update(double stockPrice);
}
