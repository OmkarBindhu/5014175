/**
 * 
 */
/**
 * @author gbind
 *
 */
module ObserverPatternExample {
}