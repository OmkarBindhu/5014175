/**
 * 
 */
/**
 * @author gbind
 *
 */
module SingletonPatternExample {
}