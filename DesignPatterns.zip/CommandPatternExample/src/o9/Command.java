package o9;

public interface Command {
    void execute();
}
