/**
 * 
 */
/**
 * @author gbind
 *
 */
module CommandPatternExample {
}