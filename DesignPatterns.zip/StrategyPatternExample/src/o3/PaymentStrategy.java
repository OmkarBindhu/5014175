package o3;

public interface PaymentStrategy {
    void pay(double amount);
}
