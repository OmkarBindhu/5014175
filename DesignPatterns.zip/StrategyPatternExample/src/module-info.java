/**
 * 
 */
/**
 * @author gbind
 *
 */
module StrategyPatternExample {
}