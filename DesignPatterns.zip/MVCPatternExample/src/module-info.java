/**
 * 
 */
/**
 * @author gbind
 *
 */
module MVCPatternExample {
}